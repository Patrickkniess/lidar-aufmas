import Foundation
import CoreGraphics
import RoomPlan
import simd

/// Ein Linienstück für den 2D-Grundriss (Draufsicht, Koordinaten in Metern).
struct PlanSegment: Identifiable {
    enum Kind { case wall, door, window, opening }
    let id = UUID()
    let a: CGPoint
    let b: CGPoint
    let kind: Kind
    let label: String?
}

/// Aufbereitete Aufmaß-Daten aus einem RoomPlan-Scan.
struct RoomReport {
    struct Wall: Identifiable {
        let id: UUID
        let index: Int
        let length: Float
        let height: Float
        let openingsArea: Float
        var grossArea: Float { length * height }
        var netArea: Float { max(0, grossArea - openingsArea) }
    }

    struct Opening: Identifiable {
        let id: UUID
        let kind: String          // Tür / Fenster / Öffnung
        let wallIndex: Int?
        let width: Float
        let height: Float
        let sillHeight: Float?    // Brüstungshöhe (nur Fenster)
    }

    struct Item: Identifiable {
        let id: UUID
        let name: String
        let width: Float
        let depth: Float
        let height: Float
    }

    let name: String
    let date: Date
    let floorArea: Float
    let perimeter: Float
    let averageHeight: Float
    let walls: [Wall]
    let openings: [Opening]
    let items: [Item]
    let segments: [PlanSegment]

    var volume: Float { floorArea * averageHeight }
    var grossWallArea: Float { walls.reduce(0) { $0 + $1.grossArea } }
    var netWallArea: Float { walls.reduce(0) { $0 + $1.netArea } }

    init(room: CapturedRoom, name: String, date: Date) {
        self.name = name
        self.date = date

        // --- Fußbodenniveau -------------------------------------------------
        let floorY: Float
        if let floor = room.floors.first {
            floorY = floor.transform.columns.3.y
        } else if let minY = room.walls.map({ $0.transform.columns.3.y - $0.dimensions.y / 2 }).min() {
            floorY = minY
        } else {
            floorY = 0
        }

        // --- Wände im Umlauf sortieren (Nummerierung rund um den Raum) -------
        let centers = room.walls.map(Self.center2D)
        let centroid: SIMD2<Float> = centers.isEmpty
            ? .zero
            : centers.reduce(.zero, +) / Float(centers.count)
        let sortedWalls = room.walls.sorted { a, b in
            let pa = Self.center2D(a) - centroid
            let pb = Self.center2D(b) - centroid
            return atan2(pa.y, pa.x) < atan2(pb.y, pb.x)
        }

        // --- Öffnungen sammeln ---------------------------------------------
        let rawOpenings: [(CapturedRoom.Surface, String)] =
            room.doors.map { ($0, "Tür") } +
            room.windows.map { ($0, "Fenster") } +
            room.openings.map { ($0, "Öffnung") }

        var openingAreaByWall: [UUID: Float] = [:]
        for (surface, _) in rawOpenings {
            if let parent = surface.parentIdentifier {
                openingAreaByWall[parent, default: 0] += surface.dimensions.x * surface.dimensions.y
            }
        }

        let wallList: [Wall] = sortedWalls.enumerated().map { i, w in
            Wall(id: w.identifier,
                 index: i + 1,
                 length: w.dimensions.x,
                 height: w.dimensions.y,
                 openingsArea: openingAreaByWall[w.identifier] ?? 0)
        }
        let wallIndexByID = Dictionary(uniqueKeysWithValues: wallList.map { ($0.id, $0.index) })

        let openingList: [Opening] = rawOpenings.map { surface, kind in
            let bottom = surface.transform.columns.3.y - surface.dimensions.y / 2 - floorY
            return Opening(id: surface.identifier,
                           kind: kind,
                           wallIndex: surface.parentIdentifier.flatMap { wallIndexByID[$0] },
                           width: surface.dimensions.x,
                           height: surface.dimensions.y,
                           sillHeight: kind == "Fenster" ? max(0, bottom) : nil)
        }

        let itemList: [Item] = room.objects.map { o in
            Item(id: o.identifier,
                 name: Self.germanName(for: o.category),
                 width: o.dimensions.x,
                 depth: o.dimensions.z,
                 height: o.dimensions.y)
        }

        // --- Bodenfläche & Umfang aus dem Bodenpolygon -----------------------
        var area: Float = 0
        var perim: Float = 0
        for floor in room.floors {
            let pts: [SIMD3<Float>] = floor.polygonCorners.map { c in
                let p = floor.transform * SIMD4<Float>(c.x, c.y, c.z, 1)
                return SIMD3<Float>(p.x, p.y, p.z)
            }
            if pts.count >= 3 {
                var normalSum = SIMD3<Float>.zero
                for i in 0..<pts.count {
                    let a = pts[i]
                    let b = pts[(i + 1) % pts.count]
                    normalSum += simd_cross(a, b)
                    perim += simd_distance(a, b)
                }
                area += simd_length(normalSum) / 2
            } else {
                let d = [floor.dimensions.x, floor.dimensions.y, floor.dimensions.z].sorted()
                area += d[1] * d[2]
            }
        }
        if perim == 0 {
            perim = wallList.reduce(0) { $0 + $1.length }
        }

        let avgHeight: Float = wallList.isEmpty
            ? 0
            : wallList.reduce(0) { $0 + $1.height } / Float(wallList.count)

        // --- Grundriss-Segmente --------------------------------------------
        var segs: [PlanSegment] = []
        for (i, w) in sortedWalls.enumerated() {
            segs.append(Self.segment(w, kind: .wall, label: "\(i + 1): \(Fmt.num(w.dimensions.x))"))
        }
        segs += room.windows.map { Self.segment($0, kind: .window, label: nil) }
        segs += room.doors.map { Self.segment($0, kind: .door, label: nil) }
        segs += room.openings.map { Self.segment($0, kind: .opening, label: nil) }

        self.floorArea = area
        self.perimeter = perim
        self.averageHeight = avgHeight
        self.walls = wallList
        self.openings = openingList
        self.items = itemList
        self.segments = segs
    }

    // MARK: - Helfer

    private static func center2D(_ s: CapturedRoom.Surface) -> SIMD2<Float> {
        SIMD2<Float>(s.transform.columns.3.x, s.transform.columns.3.z)
    }

    private static func segment(_ s: CapturedRoom.Surface, kind: PlanSegment.Kind, label: String?) -> PlanSegment {
        let t = s.transform
        let c = SIMD2<Float>(t.columns.3.x, t.columns.3.z)
        var d = SIMD2<Float>(t.columns.0.x, t.columns.0.z)
        let len = simd_length(d)
        d = len > 0 ? d / len : SIMD2<Float>(1, 0)
        let half = s.dimensions.x / 2
        let a = c - d * half
        let b = c + d * half
        return PlanSegment(a: CGPoint(x: CGFloat(a.x), y: CGFloat(a.y)),
                           b: CGPoint(x: CGFloat(b.x), y: CGFloat(b.y)),
                           kind: kind,
                           label: label)
    }

    private static let objectNames: [String: String] = [
        "storage": "Schrank/Regal",
        "refrigerator": "Kühlschrank",
        "stove": "Herd",
        "bed": "Bett",
        "sink": "Spüle/Waschbecken",
        "washerDryer": "Waschmaschine/Trockner",
        "toilet": "WC",
        "bathtub": "Badewanne",
        "oven": "Backofen",
        "dishwasher": "Spülmaschine",
        "table": "Tisch",
        "sofa": "Sofa",
        "chair": "Stuhl",
        "fireplace": "Kamin",
        "television": "Fernseher",
        "stairs": "Treppe"
    ]

    private static func germanName(for category: CapturedRoom.Object.Category) -> String {
        let key = String(describing: category)
        return objectNames[key] ?? key
    }
}
