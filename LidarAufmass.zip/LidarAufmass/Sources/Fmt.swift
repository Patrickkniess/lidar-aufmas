import Foundation

/// Zahlenformatierung im deutschen Format (Dezimalkomma).
enum Fmt {
    static func num(_ v: Float, digits: Int = 2) -> String {
        Double(v).formatted(
            .number
                .precision(.fractionLength(digits))
                .grouping(.never)
                .locale(Locale(identifier: "de_DE"))
        )
    }

    static func m(_ v: Float) -> String { num(v) + " m" }
    static func m2(_ v: Float) -> String { num(v) + " m²" }
    static func m3(_ v: Float) -> String { num(v) + " m³" }
}
