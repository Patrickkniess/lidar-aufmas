import SwiftUI

/// Maßstäblicher 2D-Grundriss (Draufsicht) mit Wandnummer und Wandlänge.
struct FloorPlanView: View {
    let report: RoomReport
    var showLegend = true

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Canvas { ctx, size in
                draw(in: &ctx, size: size)
            }
            if showLegend {
                HStack(spacing: 14) {
                    legend(.black, "Wand")
                    legend(.blue, "Fenster")
                    legend(.orange, "Tür")
                    legend(.green, "Öffnung")
                }
                .font(.caption2)
            }
        }
    }

    private func legend(_ color: Color, _ text: String) -> some View {
        HStack(spacing: 4) {
            RoundedRectangle(cornerRadius: 1).fill(color).frame(width: 14, height: 4)
            Text(text)
        }
    }

    private func draw(in ctx: inout GraphicsContext, size: CGSize) {
        let segs = report.segments
        let pts = segs.flatMap { [$0.a, $0.b] }
        guard !pts.isEmpty else { return }

        let minX = pts.map(\.x).min()!, maxX = pts.map(\.x).max()!
        let minY = pts.map(\.y).min()!, maxY = pts.map(\.y).max()!
        let w = max(maxX - minX, 0.01), h = max(maxY - minY, 0.01)
        let pad: CGFloat = 34
        let scale = min((size.width - 2 * pad) / w, (size.height - 2 * pad) / h)
        let offX = (size.width - w * scale) / 2
        let offY = (size.height - h * scale) / 2

        func map(_ p: CGPoint) -> CGPoint {
            CGPoint(x: offX + (p.x - minX) * scale, y: offY + (p.y - minY) * scale)
        }

        let center = CGPoint(x: size.width / 2, y: size.height / 2)

        // Erst Wände, dann Öffnungen darüber.
        let ordered = segs.filter { $0.kind == .wall } + segs.filter { $0.kind != .wall }
        for seg in ordered {
            let a = map(seg.a), b = map(seg.b)
            var path = Path()
            path.move(to: a)
            path.addLine(to: b)

            let (color, width): (Color, CGFloat) = switch seg.kind {
            case .wall: (.black, 4)
            case .window: (.blue, 6)
            case .door: (.orange, 6)
            case .opening: (.green, 6)
            }
            ctx.stroke(path, with: .color(color), style: StrokeStyle(lineWidth: width, lineCap: .round))

            if let label = seg.label {
                let mid = CGPoint(x: (a.x + b.x) / 2, y: (a.y + b.y) / 2)
                // Beschriftung nach außen versetzen
                var nx = -(b.y - a.y), ny = b.x - a.x
                let len = max(sqrt(nx * nx + ny * ny), 0.001)
                nx /= len; ny /= len
                if (mid.x - center.x) * nx + (mid.y - center.y) * ny < 0 { nx = -nx; ny = -ny }
                let pos = CGPoint(x: mid.x + nx * 14, y: mid.y + ny * 14)
                ctx.draw(Text(label).font(.system(size: 9, weight: .medium)).foregroundColor(.primary), at: pos)
            }
        }
    }
}
