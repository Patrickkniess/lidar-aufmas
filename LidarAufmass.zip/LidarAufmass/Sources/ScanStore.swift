import Foundation
import SwiftUI
import RoomPlan

struct ScanMeta: Codable {
    let name: String
    let date: Date
}

/// Ein gespeicherter Scan (ein Ordner in „Dokumente/Scans“).
struct SavedScan: Identifiable, Hashable {
    let folder: URL
    let name: String
    let date: Date

    var id: URL { folder }
    var metaURL: URL { folder.appendingPathComponent("meta.json") }
    var roomJSON: URL { folder.appendingPathComponent("raum.json") }
    var usdz: URL { folder.appendingPathComponent("modell.usdz") }
    var csv: URL { folder.appendingPathComponent("aufmass.csv") }
    var pdf: URL { folder.appendingPathComponent("aufmass.pdf") }

    /// Dateien, die geteilt/exportiert werden.
    var exportFiles: [URL] { [pdf, csv, usdz] }
}

@MainActor
final class ScanStore: ObservableObject {
    @Published private(set) var scans: [SavedScan] = []

    private let root: URL
    private let fm = FileManager.default

    init() {
        let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        root = docs.appendingPathComponent("Scans", isDirectory: true)
        try? fm.createDirectory(at: root, withIntermediateDirectories: true)
        reload()
    }

    func reload() {
        let folders = (try? fm.contentsOfDirectory(at: root, includingPropertiesForKeys: nil)) ?? []
        scans = folders.compactMap { folder in
            guard let data = try? Data(contentsOf: folder.appendingPathComponent("meta.json")),
                  let meta = try? JSONDecoder().decode(ScanMeta.self, from: data) else { return nil }
            return SavedScan(folder: folder, name: meta.name, date: meta.date)
        }
        .sorted { $0.date > $1.date }
    }

    @discardableResult
    func save(room: CapturedRoom, name: String) throws -> SavedScan {
        let date = Date()
        let stamp = Self.stampFormatter.string(from: date)
        let safeName = name
            .components(separatedBy: CharacterSet.alphanumerics.union(.init(charactersIn: "-_ ")).inverted)
            .joined()
            .replacingOccurrences(of: " ", with: "_")
        let folder = root.appendingPathComponent("\(safeName.isEmpty ? "Raum" : safeName)_\(stamp)", isDirectory: true)
        try fm.createDirectory(at: folder, withIntermediateDirectories: true)

        let scan = SavedScan(folder: folder, name: name, date: date)
        try JSONEncoder().encode(ScanMeta(name: name, date: date)).write(to: scan.metaURL)
        try JSONEncoder().encode(room).write(to: scan.roomJSON)
        try room.export(to: scan.usdz, exportOptions: .parametric)

        let report = RoomReport(room: room, name: name, date: date)
        try ReportExport.csv(report).write(to: scan.csv, atomically: true, encoding: .utf8)
        try ReportExport.writePDF(report, to: scan.pdf)

        reload()
        return scan
    }

    func report(for scan: SavedScan) throws -> RoomReport {
        let data = try Data(contentsOf: scan.roomJSON)
        let room = try JSONDecoder().decode(CapturedRoom.self, from: data)
        return RoomReport(room: room, name: scan.name, date: scan.date)
    }

    func delete(_ scan: SavedScan) {
        try? fm.removeItem(at: scan.folder)
        reload()
    }

    private static var stampFormatter: DateFormatter {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd_HH-mm-ss"
        return f
    }
}
