import SwiftUI
import RoomPlan

struct ContentView: View {
    @StateObject private var store = ScanStore()
    @State private var path: [SavedScan] = []

    @State private var askName = false
    @State private var roomName = ""
    @State private var activeName = ""
    @State private var showScanner = false
    @State private var errorText: String?

    private var lidarSupported: Bool { RoomCaptureSession.isSupported }

    var body: some View {
        NavigationStack(path: $path) {
            Group {
                if !lidarSupported {
                    ContentUnavailableView(
                        "LiDAR nicht verfügbar",
                        systemImage: "exclamationmark.triangle",
                        description: Text("Dieses Gerät unterstützt RoomPlan nicht. Benötigt wird ein iPhone oder iPad mit LiDAR-Scanner (z. B. iPhone 12 Pro und neuer).")
                    )
                } else if store.scans.isEmpty {
                    ContentUnavailableView(
                        "Noch keine Scans",
                        systemImage: "viewfinder",
                        description: Text("Tippe oben rechts auf +, um einen Raum aufzumessen.")
                    )
                } else {
                    List {
                        ForEach(store.scans) { scan in
                            NavigationLink(value: scan) {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(scan.name).font(.headline)
                                    Text(scan.date.formatted(date: .abbreviated, time: .shortened))
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                        .onDelete { offsets in
                            offsets.map { store.scans[$0] }.forEach { store.delete($0) }
                        }
                    }
                }
            }
            .navigationTitle("LiDAR-Aufmaß")
            .navigationDestination(for: SavedScan.self) { scan in
                ReportView(scan: scan, store: store)
            }
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button {
                        roomName = ""
                        askName = true
                    } label: {
                        Label("Neuer Scan", systemImage: "plus")
                    }
                    .disabled(!lidarSupported)
                }
            }
            .alert("Neuer Raum", isPresented: $askName) {
                TextField("z. B. Wohnzimmer EG", text: $roomName)
                Button("Scan starten") {
                    let trimmed = roomName.trimmingCharacters(in: .whitespaces)
                    activeName = trimmed.isEmpty ? "Raum" : trimmed
                    showScanner = true
                }
                Button("Abbrechen", role: .cancel) {}
            } message: {
                Text("Tipp: Langsam gehen, Kamera auf Wände, Ecken, Fenster und Türen richten.")
            }
            .fullScreenCover(isPresented: $showScanner) {
                RoomCaptureScreen(
                    roomName: activeName,
                    onCancel: { showScanner = false },
                    onSave: { room in
                        showScanner = false
                        do {
                            let scan = try store.save(room: room, name: activeName)
                            path = [scan]
                        } catch {
                            errorText = error.localizedDescription
                        }
                    }
                )
            }
            .alert("Fehler",
                   isPresented: Binding(get: { errorText != nil },
                                        set: { if !$0 { errorText = nil } })) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorText ?? "")
            }
        }
    }
}
