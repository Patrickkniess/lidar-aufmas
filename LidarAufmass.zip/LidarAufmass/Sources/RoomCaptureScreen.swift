import SwiftUI
import UIKit
import RoomPlan

/// UIKit-Controller, der Apples RoomCaptureView (LiDAR-Scan mit Live-Anleitung) einbettet.
final class RoomCaptureViewController: UIViewController, RoomCaptureViewDelegate {
    var onResult: ((CapturedRoom?, Error?) -> Void)?

    private var captureView: RoomCaptureView!
    private var isScanning = false

    override func viewDidLoad() {
        super.viewDidLoad()
        captureView = RoomCaptureView(frame: view.bounds)
        captureView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        captureView.delegate = self
        view.addSubview(captureView)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard !isScanning else { return }
        captureView.captureSession.run(configuration: RoomCaptureSession.Configuration())
        isScanning = true
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopScan()
    }

    func stopScan() {
        guard isScanning else { return }
        captureView.captureSession.stop()
        isScanning = false
    }

    // MARK: RoomCaptureViewDelegate

    func captureView(shouldPresent roomDataForProcessing: CapturedRoomData, error: Error?) -> Bool {
        true
    }

    func captureView(didPresent processedResult: CapturedRoom, error: Error?) {
        if let error {
            onResult?(nil, error)
        } else {
            onResult?(processedResult, nil)
        }
    }
}

struct RoomCaptureRepresentable: UIViewControllerRepresentable {
    let controller: RoomCaptureViewController
    func makeUIViewController(context: Context) -> RoomCaptureViewController { controller }
    func updateUIViewController(_ uiViewController: RoomCaptureViewController, context: Context) {}
}

/// Vollbild-Scanansicht mit Steuerknöpfen.
struct RoomCaptureScreen: View {
    let roomName: String
    let onCancel: () -> Void
    let onSave: (CapturedRoom) -> Void

    private enum Phase {
        case scanning
        case processing
        case finished(CapturedRoom)
        case failed(String)
    }

    @State private var controller = RoomCaptureViewController()
    @State private var phase: Phase = .scanning

    var body: some View {
        ZStack {
            RoomCaptureRepresentable(controller: controller)
                .ignoresSafeArea()

            VStack {
                Text(roomName)
                    .font(.headline)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 6)
                    .background(.ultraThinMaterial, in: Capsule())
                Spacer()
                controls
            }
            .padding()
        }
        .onAppear {
            controller.onResult = { room, error in
                if let room {
                    phase = .finished(room)
                } else {
                    phase = .failed(error?.localizedDescription ?? "Unbekannter Fehler beim Scannen.")
                }
            }
        }
    }

    @ViewBuilder
    private var controls: some View {
        switch phase {
        case .scanning:
            HStack {
                Button("Abbrechen", role: .cancel) {
                    controller.stopScan()
                    onCancel()
                }
                .buttonStyle(.bordered)
                Spacer()
                Button("Fertig") {
                    controller.stopScan()
                    phase = .processing
                }
                .buttonStyle(.borderedProminent)
            }
            .controlSize(.large)

        case .processing:
            ProgressView("Modell wird berechnet …")
                .padding()
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))

        case .finished(let room):
            HStack {
                Button("Verwerfen", role: .destructive) { onCancel() }
                    .buttonStyle(.bordered)
                Spacer()
                Button("Speichern & auswerten") { onSave(room) }
                    .buttonStyle(.borderedProminent)
            }
            .controlSize(.large)

        case .failed(let message):
            VStack(spacing: 12) {
                Text(message).multilineTextAlignment(.center)
                Button("Schließen") { onCancel() }
                    .buttonStyle(.borderedProminent)
            }
            .padding()
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
        }
    }
}
