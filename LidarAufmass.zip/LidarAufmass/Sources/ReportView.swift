import SwiftUI
import QuickLook

struct ReportView: View {
    let scan: SavedScan
    @ObservedObject var store: ScanStore

    @State private var report: RoomReport?
    @State private var loadError: String?
    @State private var previewURL: URL?

    var body: some View {
        Group {
            if let report {
                content(report)
            } else if let loadError {
                ContentUnavailableView("Scan konnte nicht geladen werden",
                                       systemImage: "xmark.octagon",
                                       description: Text(loadError))
            } else {
                ProgressView()
            }
        }
        .navigationTitle(scan.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .primaryAction) {
                Button { previewURL = scan.usdz } label: {
                    Label("3D-Modell", systemImage: "cube")
                }
                ShareLink(items: scan.exportFiles) {
                    Label("Exportieren", systemImage: "square.and.arrow.up")
                }
            }
        }
        .quickLookPreview($previewURL)
        .task {
            do { report = try store.report(for: scan) }
            catch { loadError = error.localizedDescription }
        }
    }

    private func content(_ r: RoomReport) -> some View {
        List {
            Section("Übersicht") {
                row("Grundfläche", Fmt.m2(r.floorArea))
                row("Umfang", Fmt.m(r.perimeter))
                row("Raumhöhe (Ø)", Fmt.m(r.averageHeight))
                row("Volumen", Fmt.m3(r.volume))
                row("Wandfläche brutto", Fmt.m2(r.grossWallArea))
                row("Wandfläche netto", Fmt.m2(r.netWallArea))
            }

            Section("Grundriss") {
                FloorPlanView(report: r)
                    .frame(height: 340)
                    .padding(.vertical, 8)
            }

            Section("Wände (\(r.walls.count))") {
                ForEach(r.walls) { w in
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Wand \(w.index)").font(.headline)
                        Text("Länge \(Fmt.m(w.length)) · Höhe \(Fmt.m(w.height))")
                        Text("Fläche \(Fmt.m2(w.grossArea)) brutto · \(Fmt.m2(w.netArea)) netto")
                            .foregroundStyle(.secondary)
                    }
                    .font(.subheadline)
                }
            }

            if !r.openings.isEmpty {
                Section("Türen, Fenster & Öffnungen") {
                    ForEach(r.openings) { o in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(o.kind + (o.wallIndex.map { " · Wand \($0)" } ?? "")).font(.headline)
                            Text("B \(Fmt.m(o.width)) × H \(Fmt.m(o.height))")
                            if let sill = o.sillHeight {
                                Text("Brüstungshöhe \(Fmt.m(sill))").foregroundStyle(.secondary)
                            }
                        }
                        .font(.subheadline)
                    }
                }
            }

            if !r.items.isEmpty {
                Section("Erkannte Objekte") {
                    ForEach(r.items) { i in
                        row(i.name, "\(Fmt.num(i.width)) × \(Fmt.num(i.depth)) × \(Fmt.num(i.height)) m")
                    }
                }
            }

            Section {
                Text("LiDAR-/RoomPlan-Maße haben eine Toleranz von typischerweise einigen Zentimetern. Für verbindliche Aufmaße kritische Maße mit Laser-Entfernungsmesser oder Zollstock kontrollieren.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private func row(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title)
            Spacer()
            Text(value).monospacedDigit().foregroundStyle(.secondary)
        }
    }
}
