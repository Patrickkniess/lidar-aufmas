import SwiftUI

@main
struct LidarAufmassApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
