import SwiftUI

enum ReportExport {

    // MARK: CSV (Semikolon + Dezimalkomma → öffnet direkt in deutschem Excel)

    static func csv(_ r: RoomReport) -> String {
        func clean(_ s: String) -> String { s.replacingOccurrences(of: ";", with: ",") }
        var l: [String] = []
        l.append("Raum;\(clean(r.name))")
        l.append("Datum;\(r.date.formatted(date: .numeric, time: .shortened))")
        l.append("Grundfläche (m²);\(Fmt.num(r.floorArea))")
        l.append("Umfang (m);\(Fmt.num(r.perimeter))")
        l.append("Raumhöhe Ø (m);\(Fmt.num(r.averageHeight))")
        l.append("Volumen (m³);\(Fmt.num(r.volume))")
        l.append("Wandfläche brutto (m²);\(Fmt.num(r.grossWallArea))")
        l.append("Wandfläche netto (m²);\(Fmt.num(r.netWallArea))")
        l.append("")
        l.append("Wände")
        l.append("Nr;Länge (m);Höhe (m);Fläche brutto (m²);Öffnungen (m²);Fläche netto (m²)")
        for w in r.walls {
            l.append("\(w.index);\(Fmt.num(w.length));\(Fmt.num(w.height));\(Fmt.num(w.grossArea));\(Fmt.num(w.openingsArea));\(Fmt.num(w.netArea))")
        }
        l.append("")
        l.append("Türen / Fenster / Öffnungen")
        l.append("Typ;Wand Nr;Breite (m);Höhe (m);Brüstung (m)")
        for o in r.openings {
            l.append("\(o.kind);\(o.wallIndex.map { "\($0)" } ?? "");\(Fmt.num(o.width));\(Fmt.num(o.height));\(o.sillHeight.map { Fmt.num($0) } ?? "")")
        }
        if !r.items.isEmpty {
            l.append("")
            l.append("Objekte")
            l.append("Typ;Breite (m);Tiefe (m);Höhe (m)")
            for i in r.items {
                l.append("\(i.name);\(Fmt.num(i.width));\(Fmt.num(i.depth));\(Fmt.num(i.height))")
            }
        }
        return "\u{FEFF}" + l.joined(separator: "\r\n")
    }

    // MARK: PDF (A4, eine Seite)

    @MainActor
    static func writePDF(_ report: RoomReport, to url: URL) throws {
        let page = ReportPDFPage(report: report)
            .frame(width: 595, height: 842)
            .background(Color.white)
            .environment(\.colorScheme, .light)
        let renderer = ImageRenderer(content: page)
        var ok = false
        renderer.render { size, renderInContext in
            var box = CGRect(origin: .zero, size: size)
            guard let ctx = CGContext(url as CFURL, mediaBox: &box, nil) else { return }
            ctx.beginPDFPage(nil)
            renderInContext(ctx)
            ctx.endPDFPage()
            ctx.closePDF()
            ok = true
        }
        if !ok {
            throw NSError(domain: "LidarAufmass", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "PDF konnte nicht erstellt werden."])
        }
    }
}

private struct ReportPDFPage: View {
    let report: RoomReport

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text("Aufmaß: \(report.name)").font(.system(size: 20, weight: .bold))
                Text(report.date.formatted(date: .long, time: .shortened))
                    .font(.system(size: 10)).foregroundColor(.gray)
            }

            Grid(alignment: .leading, horizontalSpacing: 24, verticalSpacing: 3) {
                GridRow { Text("Grundfläche"); Text(Fmt.m2(report.floorArea)).bold()
                          Text("Wandfläche brutto"); Text(Fmt.m2(report.grossWallArea)).bold() }
                GridRow { Text("Umfang"); Text(Fmt.m(report.perimeter)).bold()
                          Text("Wandfläche netto"); Text(Fmt.m2(report.netWallArea)).bold() }
                GridRow { Text("Raumhöhe Ø"); Text(Fmt.m(report.averageHeight)).bold()
                          Text("Volumen"); Text(Fmt.m3(report.volume)).bold() }
            }
            .font(.system(size: 10))

            FloorPlanView(report: report)
                .frame(height: 330)
                .padding(8)
                .overlay(RoundedRectangle(cornerRadius: 6).stroke(Color.gray.opacity(0.4)))

            Text("Wände").font(.system(size: 12, weight: .semibold))
            Grid(alignment: .trailing, horizontalSpacing: 16, verticalSpacing: 2) {
                GridRow {
                    Text("Nr"); Text("Länge"); Text("Höhe"); Text("Brutto"); Text("Öffn."); Text("Netto")
                }.bold()
                ForEach(report.walls.prefix(14)) { w in
                    GridRow {
                        Text("\(w.index)"); Text(Fmt.m(w.length)); Text(Fmt.m(w.height))
                        Text(Fmt.m2(w.grossArea)); Text(Fmt.m2(w.openingsArea)); Text(Fmt.m2(w.netArea))
                    }
                }
            }
            .font(.system(size: 9))

            if !report.openings.isEmpty {
                Text("Türen / Fenster / Öffnungen").font(.system(size: 12, weight: .semibold))
                Grid(alignment: .trailing, horizontalSpacing: 16, verticalSpacing: 2) {
                    GridRow { Text("Typ"); Text("Wand"); Text("Breite"); Text("Höhe"); Text("Brüstung") }.bold()
                    ForEach(report.openings.prefix(10)) { o in
                        GridRow {
                            Text(o.kind); Text(o.wallIndex.map { "\($0)" } ?? "–")
                            Text(Fmt.m(o.width)); Text(Fmt.m(o.height))
                            Text(o.sillHeight.map(Fmt.m) ?? "–")
                        }
                    }
                }
                .font(.system(size: 9))
            }

            Spacer(minLength: 0)
            Text("Erstellt per LiDAR (Apple RoomPlan). Messtoleranz typ. einige cm – maßgebliche Maße bitte nachmessen. Vollständige Listen in der CSV-Datei.")
                .font(.system(size: 7)).foregroundColor(.gray)
        }
        .padding(32)
        .foregroundColor(.black)
    }
}
